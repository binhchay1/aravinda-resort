CKEDITOR.plugins.setLang('lineheight','af', {
    title: 'linha Altura'
} );
